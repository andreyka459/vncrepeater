#!/bin/sh

LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/tmp ./vnc /tmp/vnc.conf
 


